const { app, BrowserWindow, shell, Menu, session, ipcMain } = require('electron');
const path = require('path');
const discord = require('./discord');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); }

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 420,
    minHeight: 600,
    backgroundColor: '#0d0618',
    title: 'GPC SHI 2.0',
    icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, spellcheck: false, preload: path.join(__dirname, 'preload.js') }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'index.html'));

  // ให้ชื่อหน้าต่างเป็น GPC SHI 2.0 เสมอ
  win.on('page-title-updated', (e) => e.preventDefault());

  // ลิงก์เว็บ (เช่น Roblox, Discord) เปิดในเบราว์เซอร์ปกติของเครื่อง
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (/^https?:/i.test(url)) { e.preventDefault(); shell.openExternal(url); }
  });

  // F11 = เต็มจอ
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') {
      win.setFullScreen(!win.isFullScreen());
      e.preventDefault();
    }
  });
}

app.on('second-instance', () => {
  if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});

// ===== Discord: ส่องบัญชี / ส่องเซิร์ฟเวอร์ =====
ipcMain.handle('dsc:user', (ev, id, token) => discord.user(id, token));
ipcMain.handle('dsc:invite', (ev, code) => discord.invite(code));

app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((wc, permission, cb) => {
    cb(['clipboard-sanitized-write', 'clipboard-read', 'media', 'fullscreen'].includes(permission));
  });
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
